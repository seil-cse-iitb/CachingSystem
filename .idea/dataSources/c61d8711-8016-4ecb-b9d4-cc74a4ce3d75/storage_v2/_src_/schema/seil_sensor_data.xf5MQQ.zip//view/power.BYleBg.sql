create view power as
  select `seil_sensor_data`.`power_cache`.`granularity`                                                       AS `granularity`,
         `seil_sensor_data`.`power_cache`.`sensor_id`                                                         AS `sensor_id`,
         `seil_sensor_data`.`power_cache`.`ts`                                                                AS `ts`,
         (`seil_sensor_data`.`power_cache`.`sum_power` /
          `seil_sensor_data`.`power_cache`.`count_agg_rows`)                                                  AS `power`,
         (`seil_sensor_data`.`power_cache`.`sum_voltage` /
          `seil_sensor_data`.`power_cache`.`count_agg_rows`)                                                  AS `voltage`,
         (`seil_sensor_data`.`power_cache`.`sum_current` /
          `seil_sensor_data`.`power_cache`.`count_agg_rows`)                                                  AS `current`,
         `seil_sensor_data`.`power_cache`.`energy_consumed`                                                   AS `energy_consumed`
  from `seil_sensor_data`.`power_cache`;

